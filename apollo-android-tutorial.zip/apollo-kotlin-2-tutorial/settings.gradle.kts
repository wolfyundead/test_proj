rootProject.name="apollo-android-tutorial"
include(":app")

pluginManagement {
    repositories {
        gradlePluginPortal()
        mavenCentral()
        jcenter()
    }
}