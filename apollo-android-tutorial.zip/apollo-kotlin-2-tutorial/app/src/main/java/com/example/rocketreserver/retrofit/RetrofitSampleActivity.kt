package com.example.rocketreserver.retrofit

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.rocketreserver.R
import com.example.rocketreserver.retrofit.APIClient.client
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RetrofitSampleActivity : AppCompatActivity() {
    var apiInterface: APIInterface? = null
    lateinit var textView : TextView
    lateinit var pb : ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_retrofit)
        textView = findViewById(R.id.textView)
        pb = findViewById(R.id.pb)
        apiInterface = client!!.create(APIInterface::class.java)
        val call = apiInterface?.doGetListResources()
        call!!.enqueue(object : Callback<MultipleResource?> {
            override fun onResponse(
                call: Call<MultipleResource?>,
                response: Response<MultipleResource?>
            ) {
                pb.visibility = View.GONE
                Log.d("TAG", response.code().toString() + "")
                var displayResponse = ""
                val resource = response.body()
                val text = resource!!.page
                val total = resource.total
                val totalPages = resource.totalPages
                val datumList = resource.data
                displayResponse += "${text.toString()} Page$total Total$totalPages Total Pages"
                for (datum in datumList!!) {
                    displayResponse += "${datum.id.toString()} ${datum.name} ${datum.pantoneValue} ${datum.year}"
                }
                textView.setText(displayResponse)
//                responseText.setText(displayResponse)
            }

            override fun onFailure(call: Call<MultipleResource?>, t: Throwable) {
                call.cancel()
            }
        })
    }
}