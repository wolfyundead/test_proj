package com.example.rocketreserver

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.rocketreserver.retrofit.RetrofitSampleActivity

class FirstActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first)
        findViewById<Button>(R.id.apolo).setOnClickListener(View.OnClickListener {
            startActivity(Intent(this@FirstActivity , MainActivity::class.java))
        })

        findViewById<Button>(R.id.retrofit).setOnClickListener(View.OnClickListener {
            startActivity(Intent(this@FirstActivity , RetrofitSampleActivity::class.java))
        })
    }
}
