package info.hannes.liveedgedetection

import android.graphics.Bitmap

/**
 * Interface between activity and surface view
 */
interface IScanner {
    abstract val Timber: Any

    fun displayHint(scanHint: ScanHint)
    fun onPictureClicked(bitmap: Bitmap)
}