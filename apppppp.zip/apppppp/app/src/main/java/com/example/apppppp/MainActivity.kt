package com.example.apppppp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import info.hannes.liveedgedetection.activity.ScanActivity
//var REQUEST_CODE=100
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startActivity(Intent(this, ScanActivity::class.java))
    }
}