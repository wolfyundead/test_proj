package com.example.scanactivitynew

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import info.hannes.liveedgedetection.activity.ScanActivity
val REQUEST_CODE=100
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startActivityForResult(Intent(this, ScanActivity::class.java), REQUEST_CODE)
    }
}